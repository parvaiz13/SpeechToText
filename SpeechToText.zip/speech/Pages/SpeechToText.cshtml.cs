using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace speech.Pages
{
    public class SpeechToTextModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
